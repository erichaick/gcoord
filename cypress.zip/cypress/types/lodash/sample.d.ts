import { sample } from "./index";
export = sample;
