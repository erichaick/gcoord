import { isWeakMap } from "./index";
export = isWeakMap;
