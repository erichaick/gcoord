import { repeat } from "./index";
export = repeat;
