import { orderBy } from "./index";
export = orderBy;
