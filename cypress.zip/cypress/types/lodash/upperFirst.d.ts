import { upperFirst } from "./index";
export = upperFirst;
