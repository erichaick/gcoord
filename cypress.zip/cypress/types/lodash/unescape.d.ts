import { unescape } from "./index";
export = unescape;
