import { unzip } from "./index";
export = unzip;
