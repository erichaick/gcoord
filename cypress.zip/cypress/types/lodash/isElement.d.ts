import { isElement } from "./index";
export = isElement;
