import { isString } from "./index";
export = isString;
