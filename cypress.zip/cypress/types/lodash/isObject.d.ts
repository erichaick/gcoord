import { isObject } from "./index";
export = isObject;
