import { method } from "./index";
export = method;
