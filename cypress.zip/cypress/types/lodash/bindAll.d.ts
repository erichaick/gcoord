import { bindAll } from "./index";
export = bindAll;
