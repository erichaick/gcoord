import { omit } from "./index";
export = omit;
