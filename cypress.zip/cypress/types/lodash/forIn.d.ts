import { forIn } from "./index";
export = forIn;
