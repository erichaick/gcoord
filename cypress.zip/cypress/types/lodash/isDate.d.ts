import { isDate } from "./index";
export = isDate;
