import { thru } from "./index";
export = thru;
