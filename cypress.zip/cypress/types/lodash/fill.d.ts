import { fill } from "./index";
export = fill;
